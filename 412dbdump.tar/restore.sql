--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.9 (Ubuntu 12.9-0ubuntu0.20.04.1)
-- Dumped by pg_dump version 12.9 (Ubuntu 12.9-0ubuntu0.20.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE braeden;
--
-- Name: braeden; Type: DATABASE; Schema: -; Owner: braeden
--

CREATE DATABASE braeden WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE braeden OWNER TO braeden;

\connect braeden

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: aave; Type: TABLE; Schema: public; Owner: braeden
--

CREATE TABLE public.aave (
    sno integer NOT NULL,
    name character varying(30),
    sym character varying(4),
    date character varying(25),
    high real,
    low real,
    open real,
    close real,
    volume real,
    mcap real
);


ALTER TABLE public.aave OWNER TO braeden;

--
-- Name: binancecoin; Type: TABLE; Schema: public; Owner: braeden
--

CREATE TABLE public.binancecoin (
    sno integer NOT NULL,
    name character varying(30),
    sym character varying(4),
    date character varying(25),
    high real,
    low real,
    open real,
    close real,
    volume real,
    mcap real
);


ALTER TABLE public.binancecoin OWNER TO braeden;

--
-- Name: bitcoin; Type: TABLE; Schema: public; Owner: braeden
--

CREATE TABLE public.bitcoin (
    sno integer NOT NULL,
    name character varying(30),
    sym character varying(4),
    date character varying(25),
    high real,
    low real,
    open real,
    close real,
    volume real,
    mcap real
);


ALTER TABLE public.bitcoin OWNER TO braeden;

--
-- Name: cardano; Type: TABLE; Schema: public; Owner: braeden
--

CREATE TABLE public.cardano (
    sno integer NOT NULL,
    name character varying(30),
    sym character varying(4),
    date character varying(25),
    high real,
    low real,
    open real,
    close real,
    volume real,
    mcap real
);


ALTER TABLE public.cardano OWNER TO braeden;

--
-- Name: chainlink; Type: TABLE; Schema: public; Owner: braeden
--

CREATE TABLE public.chainlink (
    sno integer NOT NULL,
    name character varying(30),
    sym character varying(4),
    date character varying(25),
    high real,
    low real,
    open real,
    close real,
    volume real,
    mcap real
);


ALTER TABLE public.chainlink OWNER TO braeden;

--
-- Name: cosmos; Type: TABLE; Schema: public; Owner: braeden
--

CREATE TABLE public.cosmos (
    sno integer NOT NULL,
    name character varying(30),
    sym character varying(4),
    date character varying(25),
    high real,
    low real,
    open real,
    close real,
    volume real,
    mcap real
);


ALTER TABLE public.cosmos OWNER TO braeden;

--
-- Name: cryptocomcoin; Type: TABLE; Schema: public; Owner: braeden
--

CREATE TABLE public.cryptocomcoin (
    sno integer NOT NULL,
    name character varying(30),
    sym character varying(4),
    date character varying(25),
    high real,
    low real,
    open real,
    close real,
    volume real,
    mcap real
);


ALTER TABLE public.cryptocomcoin OWNER TO braeden;

--
-- Name: dogecoin; Type: TABLE; Schema: public; Owner: braeden
--

CREATE TABLE public.dogecoin (
    sno integer NOT NULL,
    name character varying(30),
    sym character varying(4),
    date character varying(25),
    high real,
    low real,
    open real,
    close real,
    volume real,
    mcap real
);


ALTER TABLE public.dogecoin OWNER TO braeden;

--
-- Name: eos; Type: TABLE; Schema: public; Owner: braeden
--

CREATE TABLE public.eos (
    sno integer NOT NULL,
    name character varying(30),
    sym character varying(4),
    date character varying(25),
    high real,
    low real,
    open real,
    close real,
    volume real,
    mcap real
);


ALTER TABLE public.eos OWNER TO braeden;

--
-- Name: ethereum; Type: TABLE; Schema: public; Owner: braeden
--

CREATE TABLE public.ethereum (
    sno integer NOT NULL,
    name character varying(30),
    sym character varying(4),
    date character varying(25),
    high real,
    low real,
    open real,
    close real,
    volume real,
    mcap real
);


ALTER TABLE public.ethereum OWNER TO braeden;

--
-- Name: iota; Type: TABLE; Schema: public; Owner: braeden
--

CREATE TABLE public.iota (
    sno integer NOT NULL,
    name character varying(30),
    sym character varying(4),
    date character varying(25),
    high real,
    low real,
    open real,
    close real,
    volume real,
    mcap real
);


ALTER TABLE public.iota OWNER TO braeden;

--
-- Name: litecoin; Type: TABLE; Schema: public; Owner: braeden
--

CREATE TABLE public.litecoin (
    sno integer NOT NULL,
    name character varying(30),
    sym character varying(4),
    date character varying(25),
    high real,
    low real,
    open real,
    close real,
    volume real,
    mcap real
);


ALTER TABLE public.litecoin OWNER TO braeden;

--
-- Name: monero; Type: TABLE; Schema: public; Owner: braeden
--

CREATE TABLE public.monero (
    sno integer NOT NULL,
    name character varying(30),
    sym character varying(4),
    date character varying(25),
    high real,
    low real,
    open real,
    close real,
    volume real,
    mcap real
);


ALTER TABLE public.monero OWNER TO braeden;

--
-- Name: nem; Type: TABLE; Schema: public; Owner: braeden
--

CREATE TABLE public.nem (
    sno integer NOT NULL,
    name character varying(30),
    sym character varying(4),
    date character varying(25),
    high real,
    low real,
    open real,
    close real,
    volume real,
    mcap real
);


ALTER TABLE public.nem OWNER TO braeden;

--
-- Name: polkadot; Type: TABLE; Schema: public; Owner: braeden
--

CREATE TABLE public.polkadot (
    sno integer NOT NULL,
    name character varying(30),
    sym character varying(4),
    date character varying(25),
    high real,
    low real,
    open real,
    close real,
    volume real,
    mcap real
);


ALTER TABLE public.polkadot OWNER TO braeden;

--
-- Name: solana; Type: TABLE; Schema: public; Owner: braeden
--

CREATE TABLE public.solana (
    sno integer NOT NULL,
    name character varying(30),
    sym character varying(4),
    date character varying(25),
    high real,
    low real,
    open real,
    close real,
    volume real,
    mcap real
);


ALTER TABLE public.solana OWNER TO braeden;

--
-- Name: stellar; Type: TABLE; Schema: public; Owner: braeden
--

CREATE TABLE public.stellar (
    sno integer NOT NULL,
    name character varying(30),
    sym character varying(4),
    date character varying(25),
    high real,
    low real,
    open real,
    close real,
    volume real,
    mcap real
);


ALTER TABLE public.stellar OWNER TO braeden;

--
-- Name: tether; Type: TABLE; Schema: public; Owner: braeden
--

CREATE TABLE public.tether (
    sno integer NOT NULL,
    name character varying(30),
    sym character varying(4),
    date character varying(25),
    high real,
    low real,
    open real,
    close real,
    volume real,
    mcap real
);


ALTER TABLE public.tether OWNER TO braeden;

--
-- Name: tron; Type: TABLE; Schema: public; Owner: braeden
--

CREATE TABLE public.tron (
    sno integer NOT NULL,
    name character varying(30),
    sym character varying(4),
    date character varying(25),
    high real,
    low real,
    open real,
    close real,
    volume real,
    mcap real
);


ALTER TABLE public.tron OWNER TO braeden;

--
-- Name: uniswap; Type: TABLE; Schema: public; Owner: braeden
--

CREATE TABLE public.uniswap (
    sno integer NOT NULL,
    name character varying(30),
    sym character varying(4),
    date character varying(25),
    high real,
    low real,
    open real,
    close real,
    volume real,
    mcap real
);


ALTER TABLE public.uniswap OWNER TO braeden;

--
-- Name: usdcoin; Type: TABLE; Schema: public; Owner: braeden
--

CREATE TABLE public.usdcoin (
    sno integer NOT NULL,
    name character varying(30),
    sym character varying(4),
    date character varying(25),
    high real,
    low real,
    open real,
    close real,
    volume real,
    mcap real
);


ALTER TABLE public.usdcoin OWNER TO braeden;

--
-- Name: wrappedbitcoin; Type: TABLE; Schema: public; Owner: braeden
--

CREATE TABLE public.wrappedbitcoin (
    sno integer NOT NULL,
    name character varying(30),
    sym character varying(4),
    date character varying(25),
    high real,
    low real,
    open real,
    close real,
    volume real,
    mcap real
);


ALTER TABLE public.wrappedbitcoin OWNER TO braeden;

--
-- Name: xrp; Type: TABLE; Schema: public; Owner: braeden
--

CREATE TABLE public.xrp (
    sno integer NOT NULL,
    name character varying(30),
    sym character varying(4),
    date character varying(25),
    high real,
    low real,
    open real,
    close real,
    volume real,
    mcap real
);


ALTER TABLE public.xrp OWNER TO braeden;

--
-- Data for Name: aave; Type: TABLE DATA; Schema: public; Owner: braeden
--

COPY public.aave (sno, name, sym, date, high, low, open, close, volume, mcap) FROM stdin;
\.
COPY public.aave (sno, name, sym, date, high, low, open, close, volume, mcap) FROM '$$PATH$$/3088.dat';

--
-- Data for Name: binancecoin; Type: TABLE DATA; Schema: public; Owner: braeden
--

COPY public.binancecoin (sno, name, sym, date, high, low, open, close, volume, mcap) FROM stdin;
\.
COPY public.binancecoin (sno, name, sym, date, high, low, open, close, volume, mcap) FROM '$$PATH$$/3089.dat';

--
-- Data for Name: bitcoin; Type: TABLE DATA; Schema: public; Owner: braeden
--

COPY public.bitcoin (sno, name, sym, date, high, low, open, close, volume, mcap) FROM stdin;
\.
COPY public.bitcoin (sno, name, sym, date, high, low, open, close, volume, mcap) FROM '$$PATH$$/3090.dat';

--
-- Data for Name: cardano; Type: TABLE DATA; Schema: public; Owner: braeden
--

COPY public.cardano (sno, name, sym, date, high, low, open, close, volume, mcap) FROM stdin;
\.
COPY public.cardano (sno, name, sym, date, high, low, open, close, volume, mcap) FROM '$$PATH$$/3091.dat';

--
-- Data for Name: chainlink; Type: TABLE DATA; Schema: public; Owner: braeden
--

COPY public.chainlink (sno, name, sym, date, high, low, open, close, volume, mcap) FROM stdin;
\.
COPY public.chainlink (sno, name, sym, date, high, low, open, close, volume, mcap) FROM '$$PATH$$/3092.dat';

--
-- Data for Name: cosmos; Type: TABLE DATA; Schema: public; Owner: braeden
--

COPY public.cosmos (sno, name, sym, date, high, low, open, close, volume, mcap) FROM stdin;
\.
COPY public.cosmos (sno, name, sym, date, high, low, open, close, volume, mcap) FROM '$$PATH$$/3093.dat';

--
-- Data for Name: cryptocomcoin; Type: TABLE DATA; Schema: public; Owner: braeden
--

COPY public.cryptocomcoin (sno, name, sym, date, high, low, open, close, volume, mcap) FROM stdin;
\.
COPY public.cryptocomcoin (sno, name, sym, date, high, low, open, close, volume, mcap) FROM '$$PATH$$/3094.dat';

--
-- Data for Name: dogecoin; Type: TABLE DATA; Schema: public; Owner: braeden
--

COPY public.dogecoin (sno, name, sym, date, high, low, open, close, volume, mcap) FROM stdin;
\.
COPY public.dogecoin (sno, name, sym, date, high, low, open, close, volume, mcap) FROM '$$PATH$$/3095.dat';

--
-- Data for Name: eos; Type: TABLE DATA; Schema: public; Owner: braeden
--

COPY public.eos (sno, name, sym, date, high, low, open, close, volume, mcap) FROM stdin;
\.
COPY public.eos (sno, name, sym, date, high, low, open, close, volume, mcap) FROM '$$PATH$$/3096.dat';

--
-- Data for Name: ethereum; Type: TABLE DATA; Schema: public; Owner: braeden
--

COPY public.ethereum (sno, name, sym, date, high, low, open, close, volume, mcap) FROM stdin;
\.
COPY public.ethereum (sno, name, sym, date, high, low, open, close, volume, mcap) FROM '$$PATH$$/3097.dat';

--
-- Data for Name: iota; Type: TABLE DATA; Schema: public; Owner: braeden
--

COPY public.iota (sno, name, sym, date, high, low, open, close, volume, mcap) FROM stdin;
\.
COPY public.iota (sno, name, sym, date, high, low, open, close, volume, mcap) FROM '$$PATH$$/3098.dat';

--
-- Data for Name: litecoin; Type: TABLE DATA; Schema: public; Owner: braeden
--

COPY public.litecoin (sno, name, sym, date, high, low, open, close, volume, mcap) FROM stdin;
\.
COPY public.litecoin (sno, name, sym, date, high, low, open, close, volume, mcap) FROM '$$PATH$$/3099.dat';

--
-- Data for Name: monero; Type: TABLE DATA; Schema: public; Owner: braeden
--

COPY public.monero (sno, name, sym, date, high, low, open, close, volume, mcap) FROM stdin;
\.
COPY public.monero (sno, name, sym, date, high, low, open, close, volume, mcap) FROM '$$PATH$$/3100.dat';

--
-- Data for Name: nem; Type: TABLE DATA; Schema: public; Owner: braeden
--

COPY public.nem (sno, name, sym, date, high, low, open, close, volume, mcap) FROM stdin;
\.
COPY public.nem (sno, name, sym, date, high, low, open, close, volume, mcap) FROM '$$PATH$$/3101.dat';

--
-- Data for Name: polkadot; Type: TABLE DATA; Schema: public; Owner: braeden
--

COPY public.polkadot (sno, name, sym, date, high, low, open, close, volume, mcap) FROM stdin;
\.
COPY public.polkadot (sno, name, sym, date, high, low, open, close, volume, mcap) FROM '$$PATH$$/3102.dat';

--
-- Data for Name: solana; Type: TABLE DATA; Schema: public; Owner: braeden
--

COPY public.solana (sno, name, sym, date, high, low, open, close, volume, mcap) FROM stdin;
\.
COPY public.solana (sno, name, sym, date, high, low, open, close, volume, mcap) FROM '$$PATH$$/3103.dat';

--
-- Data for Name: stellar; Type: TABLE DATA; Schema: public; Owner: braeden
--

COPY public.stellar (sno, name, sym, date, high, low, open, close, volume, mcap) FROM stdin;
\.
COPY public.stellar (sno, name, sym, date, high, low, open, close, volume, mcap) FROM '$$PATH$$/3104.dat';

--
-- Data for Name: tether; Type: TABLE DATA; Schema: public; Owner: braeden
--

COPY public.tether (sno, name, sym, date, high, low, open, close, volume, mcap) FROM stdin;
\.
COPY public.tether (sno, name, sym, date, high, low, open, close, volume, mcap) FROM '$$PATH$$/3105.dat';

--
-- Data for Name: tron; Type: TABLE DATA; Schema: public; Owner: braeden
--

COPY public.tron (sno, name, sym, date, high, low, open, close, volume, mcap) FROM stdin;
\.
COPY public.tron (sno, name, sym, date, high, low, open, close, volume, mcap) FROM '$$PATH$$/3106.dat';

--
-- Data for Name: uniswap; Type: TABLE DATA; Schema: public; Owner: braeden
--

COPY public.uniswap (sno, name, sym, date, high, low, open, close, volume, mcap) FROM stdin;
\.
COPY public.uniswap (sno, name, sym, date, high, low, open, close, volume, mcap) FROM '$$PATH$$/3107.dat';

--
-- Data for Name: usdcoin; Type: TABLE DATA; Schema: public; Owner: braeden
--

COPY public.usdcoin (sno, name, sym, date, high, low, open, close, volume, mcap) FROM stdin;
\.
COPY public.usdcoin (sno, name, sym, date, high, low, open, close, volume, mcap) FROM '$$PATH$$/3108.dat';

--
-- Data for Name: wrappedbitcoin; Type: TABLE DATA; Schema: public; Owner: braeden
--

COPY public.wrappedbitcoin (sno, name, sym, date, high, low, open, close, volume, mcap) FROM stdin;
\.
COPY public.wrappedbitcoin (sno, name, sym, date, high, low, open, close, volume, mcap) FROM '$$PATH$$/3109.dat';

--
-- Data for Name: xrp; Type: TABLE DATA; Schema: public; Owner: braeden
--

COPY public.xrp (sno, name, sym, date, high, low, open, close, volume, mcap) FROM stdin;
\.
COPY public.xrp (sno, name, sym, date, high, low, open, close, volume, mcap) FROM '$$PATH$$/3110.dat';

--
-- Name: aave aave_pkey; Type: CONSTRAINT; Schema: public; Owner: braeden
--

ALTER TABLE ONLY public.aave
    ADD CONSTRAINT aave_pkey PRIMARY KEY (sno);


--
-- Name: binancecoin binancecoin_pkey; Type: CONSTRAINT; Schema: public; Owner: braeden
--

ALTER TABLE ONLY public.binancecoin
    ADD CONSTRAINT binancecoin_pkey PRIMARY KEY (sno);


--
-- Name: bitcoin bitcoin_pkey; Type: CONSTRAINT; Schema: public; Owner: braeden
--

ALTER TABLE ONLY public.bitcoin
    ADD CONSTRAINT bitcoin_pkey PRIMARY KEY (sno);


--
-- Name: cardano cardano_pkey; Type: CONSTRAINT; Schema: public; Owner: braeden
--

ALTER TABLE ONLY public.cardano
    ADD CONSTRAINT cardano_pkey PRIMARY KEY (sno);


--
-- Name: chainlink chainlink_pkey; Type: CONSTRAINT; Schema: public; Owner: braeden
--

ALTER TABLE ONLY public.chainlink
    ADD CONSTRAINT chainlink_pkey PRIMARY KEY (sno);


--
-- Name: cosmos cosmos_pkey; Type: CONSTRAINT; Schema: public; Owner: braeden
--

ALTER TABLE ONLY public.cosmos
    ADD CONSTRAINT cosmos_pkey PRIMARY KEY (sno);


--
-- Name: cryptocomcoin cryptocomcoin_pkey; Type: CONSTRAINT; Schema: public; Owner: braeden
--

ALTER TABLE ONLY public.cryptocomcoin
    ADD CONSTRAINT cryptocomcoin_pkey PRIMARY KEY (sno);


--
-- Name: dogecoin dogecoin_pkey; Type: CONSTRAINT; Schema: public; Owner: braeden
--

ALTER TABLE ONLY public.dogecoin
    ADD CONSTRAINT dogecoin_pkey PRIMARY KEY (sno);


--
-- Name: eos eos_pkey; Type: CONSTRAINT; Schema: public; Owner: braeden
--

ALTER TABLE ONLY public.eos
    ADD CONSTRAINT eos_pkey PRIMARY KEY (sno);


--
-- Name: ethereum ethereum_pkey; Type: CONSTRAINT; Schema: public; Owner: braeden
--

ALTER TABLE ONLY public.ethereum
    ADD CONSTRAINT ethereum_pkey PRIMARY KEY (sno);


--
-- Name: iota iota_pkey; Type: CONSTRAINT; Schema: public; Owner: braeden
--

ALTER TABLE ONLY public.iota
    ADD CONSTRAINT iota_pkey PRIMARY KEY (sno);


--
-- Name: litecoin litecoin_pkey; Type: CONSTRAINT; Schema: public; Owner: braeden
--

ALTER TABLE ONLY public.litecoin
    ADD CONSTRAINT litecoin_pkey PRIMARY KEY (sno);


--
-- Name: monero monero_pkey; Type: CONSTRAINT; Schema: public; Owner: braeden
--

ALTER TABLE ONLY public.monero
    ADD CONSTRAINT monero_pkey PRIMARY KEY (sno);


--
-- Name: nem nem_pkey; Type: CONSTRAINT; Schema: public; Owner: braeden
--

ALTER TABLE ONLY public.nem
    ADD CONSTRAINT nem_pkey PRIMARY KEY (sno);


--
-- Name: polkadot polkadot_pkey; Type: CONSTRAINT; Schema: public; Owner: braeden
--

ALTER TABLE ONLY public.polkadot
    ADD CONSTRAINT polkadot_pkey PRIMARY KEY (sno);


--
-- Name: solana solana_pkey; Type: CONSTRAINT; Schema: public; Owner: braeden
--

ALTER TABLE ONLY public.solana
    ADD CONSTRAINT solana_pkey PRIMARY KEY (sno);


--
-- Name: stellar stellar_pkey; Type: CONSTRAINT; Schema: public; Owner: braeden
--

ALTER TABLE ONLY public.stellar
    ADD CONSTRAINT stellar_pkey PRIMARY KEY (sno);


--
-- Name: tether tether_pkey; Type: CONSTRAINT; Schema: public; Owner: braeden
--

ALTER TABLE ONLY public.tether
    ADD CONSTRAINT tether_pkey PRIMARY KEY (sno);


--
-- Name: tron tron_pkey; Type: CONSTRAINT; Schema: public; Owner: braeden
--

ALTER TABLE ONLY public.tron
    ADD CONSTRAINT tron_pkey PRIMARY KEY (sno);


--
-- Name: uniswap uniswap_pkey; Type: CONSTRAINT; Schema: public; Owner: braeden
--

ALTER TABLE ONLY public.uniswap
    ADD CONSTRAINT uniswap_pkey PRIMARY KEY (sno);


--
-- Name: usdcoin usdcoin_pkey; Type: CONSTRAINT; Schema: public; Owner: braeden
--

ALTER TABLE ONLY public.usdcoin
    ADD CONSTRAINT usdcoin_pkey PRIMARY KEY (sno);


--
-- Name: wrappedbitcoin wrappedbitcoin_pkey; Type: CONSTRAINT; Schema: public; Owner: braeden
--

ALTER TABLE ONLY public.wrappedbitcoin
    ADD CONSTRAINT wrappedbitcoin_pkey PRIMARY KEY (sno);


--
-- Name: xrp xrp_pkey; Type: CONSTRAINT; Schema: public; Owner: braeden
--

ALTER TABLE ONLY public.xrp
    ADD CONSTRAINT xrp_pkey PRIMARY KEY (sno);


--
-- PostgreSQL database dump complete
--

